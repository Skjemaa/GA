context("select")

test_that("dummy test", {
  expect_equal(select(), 1)
})
